import sys
import Levenshtein

#I could not do this task, I will expand upon it in the future

def readDictionary(dictionaryFileName):
    dictionaryWords = []
    input = open(dictionaryFilename, 'r')


arguments = sys.argv[1: ]
