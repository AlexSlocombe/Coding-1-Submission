""" Write a program that given a list of numbers, multiply all numbers in the list. 
Bonus for ignoring non-number element. Example: input: [1, 2, 3, 4], output: 24"""

j = 1
nums=[1, 2, 3, 4]
for i in nums:
    j = i * j
print(j)





